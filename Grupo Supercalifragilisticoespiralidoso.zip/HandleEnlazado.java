package aed;
// interfaz creada para el uso de Handles en lista Enlazada para obtener acceso O(1)
// sin tener que exponer los nodos directamente
public interface HandleEnlazado {
   void eliminar(); //se encargada de eliminar el nodo de la transaccion hackeada
}
