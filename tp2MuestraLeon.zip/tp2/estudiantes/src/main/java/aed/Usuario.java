package aed;
 //un usuario tendra id, saldo y ademas un handle para busqueda en O(1)
public class Usuario implements Comparable<Usuario>, HeapHandle { 
    private int id;
    private int saldo;
    private int indiceHeap; 

    //primero inicializamos usuario con su id y sueldo
    // no es necesario iniciar el indice pues se iniciara al agregar al usuario al heap
    public Usuario(int id, int saldo) { 
        this.id = id;
        this.saldo = saldo; 
    }

    //necesitamos poder comparar usuarios según su id (descendente) y saldo (ascendente)
    public int compareTo(Usuario otro) {
        if (this.saldo != otro.saldo) {
            return this.saldo - otro.saldo; // mayor saldo primero
        }
        return otro.id - this.id; // menor id en empate
    }

    public boolean equals(Object otro) {
        if (this == otro) { 
            return true;
        } 
        else {
            if (otro == null || getClass() != otro.getClass()) { 
                return false;
            }
            else { 
                 Usuario usuario = (Usuario) otro; 
                 return id == usuario.id;
            }
        }
    } // seran distintos solo si 1. o es null, 2. son de distinta clase 3. tienen distinto id 

    @Override
    public void indiceHeap(int indice) { // seteamos el indice 
        indiceHeap = indice;
    }

    @Override
    public int obtenerIndiceHeap() { // quiero ver el indice
        return indiceHeap;
    }
    // funciones para obtener los valores de los atributos privados
    public int verId() { 
        return id; 
    }
    public int verSaldo() { 
        return saldo; 
    }
    public void modificarSaldo(int saldo) { 
        this.saldo = saldo; 
    }
}
