package aed;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class HeapGenericoTests {
    private HeapGenerico<Usuario> heapUsuarios;
    private HeapGenerico<Transaccion> heapTransacciones;
    private ArrayList<Usuario> listaUsuarios;
    private ArrayList<Transaccion> listaTransacciones;

    @BeforeEach
    void setUp() {
        listaUsuarios = new ArrayList<>();
        listaTransacciones = new ArrayList<>();

        listaUsuarios.add(new Usuario(1, 0));
        listaUsuarios.add(new Usuario(2, 0));
        listaUsuarios.add(new Usuario(3, 0));
        listaUsuarios.add(new Usuario(4, 0));
        listaUsuarios.add(new Usuario(5, 0));
        listaUsuarios.add(new Usuario(6, 0));
        listaUsuarios.add(new Usuario(7, 0));
        listaUsuarios.add(new Usuario(8, 0));
    
        listaTransacciones.add(new Transaccion(0, 0, 1, 1));
        listaTransacciones.add(new Transaccion(1, 1, 2, 2));
        listaTransacciones.add(new Transaccion(2, 2, 3, 3));
        listaTransacciones.add(new Transaccion(3, 3, 1, 2));
        listaTransacciones.add(new Transaccion(4, 1, 2, 1));
        listaTransacciones.add(new Transaccion(5, 2, 3, 1));
    
        heapUsuarios = new HeapGenerico<>(listaUsuarios);
        heapTransacciones = new HeapGenerico<>(listaTransacciones);
    }

   @Test
   public void crearHeapUsuarios() {
    assertEquals(1, heapUsuarios.verMaximo().verId());

    for (int i = 0; i < listaUsuarios.size(); i++) {
        Usuario u = listaUsuarios.get(i);
        assertEquals(i, u.obtenerIndiceHeap());
    }
}

   @Test
   public void crearHeapTransacciones() {
    assertEquals(2, heapTransacciones.verMaximo().id());
   }


   @Test
   public void extraerHastaVaciar(){
    heapTransacciones.extraerMaximo();
    heapTransacciones.extraerMaximo();
    heapTransacciones.extraerMaximo();
    heapTransacciones.extraerMaximo();
    heapTransacciones.extraerMaximo();
    heapTransacciones.extraerMaximo();
    assertEquals(0, heapTransacciones.longitudHeap());
   }

   @Test 
   public void nuevoUsuarioMaximo() {
    Usuario nuevoMaximo = listaUsuarios.get(7);
    nuevoMaximo.modificarSaldo(20);
    heapUsuarios.actualizarElemento(nuevoMaximo.obtenerIndiceHeap());
    assertEquals(8, heapUsuarios.verMaximo().verId());
   }
}
